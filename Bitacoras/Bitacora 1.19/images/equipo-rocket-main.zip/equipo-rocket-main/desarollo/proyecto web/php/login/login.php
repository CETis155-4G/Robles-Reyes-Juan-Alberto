<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0,
	maximum-scale:2.0, user scalable-1" />
	<link rel="stylesheet" href="../assets/styles/style.css">
	<link rel="stylesheet" href="../assets/styles/spacing.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/styles2?family=Roboto+Bold">
	<title> Login </title>
</head>






<body>

	<ul class="choose-color">
        <li><a href="login.php"> Login</a></li>
		<li><a href="../registro/registro.php"> Registrarse </a></li>
		<li><a href="../index.php"> Menu </a></li>
	</ul>

<main>



<table class="align-x w-10 cmt-8 cmb-8">
		<tr>
			<!-- IMAGEN -->
			<div>
				<td class="w-5" id="data-image">
                    <img src="../assets/images/fondos/pizza_background.jpg" alt="">
				</td>
			</div>
			<!-- CONTENIDO (LOGIN) -->
			<td class="w-5 cp-3 cpt-5 cpb-6" id="data-content">

				<h1 class=" fc-1 fs-1 cmb-4"> LOGIN </h1>
				<h2 class="fc-3 fs-2"> Email </h2>
				<input requiered class="fc-2 fs-3" type="email" name="email" id="email">
				<h2 class="fc-3 fs-2"> Contraseña </h2>
				<input requiered class="fc-2 fs-3" type="password" name="password" id="password">
				<button class="btn fs-3"> LOGIN </button>

			</td>
		</tr>
	</table>




</main>
    
</body>