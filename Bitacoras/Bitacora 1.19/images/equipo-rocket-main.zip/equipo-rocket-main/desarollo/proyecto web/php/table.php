<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=}, initial-scale=1.0">
    <title>Document</title>
</head>


<body>
    <table>
        <thead>
            <tr>
                <!-- Se crean 3 columnas dentro de una fila -->
                <th> Procucto 1 </th>
                <th> Procucto 2 </th>
                <th> Procucto 3 </th>
            </tr>
        </thead>

        <tbody>
            <!-- Se recuperan los productos de la base de datos -->
            
            <!-- Se ingresan los datos en un nuevo conjunto de 3 productos -->
            <tr>
                <td>
                    <?php foreach ($): ?>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>