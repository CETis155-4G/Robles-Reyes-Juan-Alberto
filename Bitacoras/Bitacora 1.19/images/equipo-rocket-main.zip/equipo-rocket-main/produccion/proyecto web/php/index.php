<!DOCTYPE html>
<html>
    <head>
        <!-- Es el titulo que aparece en la pestalla -->
        <title>CSS</title>
        <!-- Se le el css -->
    <link rel="stylesheet" href="./assets/css/main.css" type="text/css"/>
    </head>
    <body>
        <ul class="cabezera">
            <li class="active"><a href="#">Inicio</a></li>
        <li><a href="./login/login.php">login</a></li>
        </ul>
        <div class="bie">
            <h2>Bienvenido</h2>
        </div>
        <!-- Aqui hay un contenedor que cada formulario es una linea de imagenes -->
        <div class="con">
            <form  action="">
                <div>
                <img src="./assets/images/agua.jpg" width="200px" height="200px" alt="agu">
                <input type="button" value="agua" >
            </div>
            <div>
                <img src="./assets/images/arizo.jpg"  width="200px" height="200px" alt="">
                <input type="button" value="Arizona">
            </div>
            <div>
                <img src="./assets/images/braw.jpg" width="200px" height="200px" alt="agu">
                <input type="button" value="agua" >
            </div>
            <div>
                <img src="./assets/images/burrit.jpg"  width="200px" height="200px" alt="">
                <input type="button" value="Arizona">
                </div>
                <div>
                    <img src="./assets/images/cacahuateg.jpg" width="200px" height="200px" alt="agu">
                    <input type="button" value="agua" >
                </div>
                <div>
                    <img src="./assets/images/cafe.jpg"  width="200px" height="200px" alt="">
                    <input type="button" value="Arizona">
                </div>
                <div>
                    <img src="./assets/images/coco.jpg" width="200px" height="200px" alt="agu">
                    <input type="button" value="agua" >
                </div>
            </form>
            <form action="">
                <div>
                    <img src="./assets/images/fresa.jpg"  width="200px" height="200px" alt="">
                    <input type="button" value="Arizona">
                    </div>
                    <div>
                        <img src="./assets/images/fuze te.jpg" width="200px" height="200px" alt="agu">
                        <input type="button" value="agua" >
                    </div>
                    <div>
                        <img src="./assets/images/fuze tea limon.jpg"  width="200px" height="200px" alt="">
                        <input type="button" value="Arizona">
                    </div>
                    <div>
                        <img src="./assets/images/ham.jpg" width="200px" height="200px" alt="agu">
                        <input type="button" value="agua" >
                    </div>
                    <div>
                        <img src="./assets/images/horcha.jpg"  width="200px" height="200px" alt="">
                        <input type="button" value="Arizona">
                        </div>
                        <div>
                            <img src="./assets/images/lim.jpg" width="200px" height="200px" alt="agu">
                            <input type="button" value="agua" >
                        </div>
                        <div>
                            <img src="./assets/images/pays.jpg"  width="200px" height="200px" alt="">
                            <input type="button" value="Arizona">
                        </div>
            </form>
            <form action="">
                <div>
                    <img src="./assets/images/pizza.jpg"  width="200px" height="200px" alt="">
                    <input type="button" value="Arizona">
                    </div>
                    <div>
                        <img src="./assets/images/powa.jpg" width="200px" height="200px" alt="agu">
                        <input type="button" value="agua" >
                    </div>
                    <div>
                        <img src="./assets/images/powr.jpg"  width="200px" height="200px" alt="">
                        <input type="button" value="Arizona">
                    </div>
                    <div>
                        <img src="./assets/images/principe.png" width="200px" height="200px" alt="agu">
                        <input type="button" value="agua" >
                    </div>
                    <div>
                        <img src="./assets/images/tor.jpg"  width="200px" height="200px" alt="">
                        <input type="button" value="Arizona">
            </form>
        </div>
    </body>
</html>