<?php

$conex = mysqli_connect("localhost","root","","paises"); 

?>